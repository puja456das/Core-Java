package org.anudip.mavenApplication.collection;
import java.util.LinkedHashMap;
import java.util.Set;

public class LinkedHashMapDemo1 {

	public static void main(String[] args) {
		LinkedHashMap<Integer,String>myMap=new LinkedHashMap<>();
		myMap.put(103, "Rose");
		myMap.put(104, "Tulip");
		myMap.put(109, "Cosmos");
		myMap.put(101, "Rose");
		myMap.put(105, "Marigold");
		myMap.put(108,"Lotus");
		Set<Integer>allKeys=myMap.keySet();
		//System.out.println(allKeys);
		for(Integer ig:allKeys) {
			String str=myMap.get(ig);
			System.out.println(ig+"-"+str);
		}
		
		
		
	}
}
		