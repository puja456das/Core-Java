package org.anudip.mavenApplication.collection;
import java.util.HashMap;
import java.util.Set;

public class HashMapDemo2 {

	public static void main(String[] args) {
		HashMap<Integer,String>myMap=new HashMap<>();
		myMap.put(103, "Rose");
		myMap.put(104, "Tulip");
		myMap.put(109, "Cosmos");
		myMap.put(101, "Rose");
		myMap.put(105, "Marigold");
		myMap.put(108,"Lotus");
		Set<Integer>allKeys=myMap.keySet();
		//System.out.println(allKeys);
		for(Integer ig:allKeys) {
			String str=myMap.get(ig);
			System.out.println(ig+"-"+str);
		}
		
		
		
	}
}
		