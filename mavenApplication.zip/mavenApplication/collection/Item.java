package org.anudip.mavenApplication.collection;

import java.util.Comparator;

public class Item {
	private Integer productId;
	private String productName;
	private Double productPrice;
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Item(Integer productId, String productName, Double productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		String output=String.format("%-5s %-15s %-10s",productId,productName,productPrice);
		return  output;
	}

}//end of Item class

//compare productIds to item objects
class IdComparator implements Comparator<Item>{
	public int compare(Item first,Item second) {
		Integer firstId = first.getProductId();
		Integer secondId = second.getProductId();
		return firstId.compareTo(secondId);
	}
}

//compare productNames to item objects
class NameComparator implements Comparator<Item>{
	public int compare(Item first,Item second) {
		String firstName = first.getProductName();
		String secondName = second.getProductName();
		return firstName.compareTo(secondName);
	}
}

//compare productPrices to item objects
class PriceComparator implements Comparator<Item>{
	public int compare(Item first,Item second) {
		Double firstPrice = first.getProductPrice();
		Double secondPrice = second.getProductPrice();
		return firstPrice.compareTo(secondPrice);
	}
}