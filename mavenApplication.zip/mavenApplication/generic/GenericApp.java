package org.anudip.mavenApplication.generic;

public class GenericApp {
	public static void main(String args[]) {
		Integer i=5;
		Integer j=6;
		Double d1=6.75;
		Double d2=4.56;
		String str="ABC";
		String stg="XYZ";
		GenericDemo<Integer>gd1=new GenericDemo<>();
		gd1.swapData(i,j);
		GenericDemo<String>gd2=new GenericDemo<>();
		gd2.swapData(str,stg);
		GenericDemo<Double>gd3=new GenericDemo<>();
		gd3.swapData(d1,d2);
	}

}
