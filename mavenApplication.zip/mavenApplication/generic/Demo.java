package org.anudip.mavenApplication.generic;

public class Demo {
	int p;
	double q;
	

}
