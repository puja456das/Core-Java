package org.anudip.mavenApplication.app;

import java.text.DecimalFormat;

public class EmployeeService {
	public String taxCalculation(Employee employee) {
		String tax = "0.00";
		double val = 0.0;
		double salary = employee.getSalary();
		double annual = salary*12;
		if(annual>=1500000.00)
			val = annual*0.25;
		else if(annual>=1000000.00)
			val = annual*0.2;
		else if(annual>=500000.00)
			val = annual*0.1;
		else 
			val = 0.00;
		DecimalFormat decimalFormat = new DecimalFormat("0.00");
		tax = decimalFormat.format(val);
		return tax;
	}
}