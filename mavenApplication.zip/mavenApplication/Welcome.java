package org.anudip.mavenApplication;

public class Welcome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello,ANP-5904");
    System.out.println("Welcome to Maven");

	}

}
