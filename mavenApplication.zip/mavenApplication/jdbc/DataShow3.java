package org.anudip.mavenApplication.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;
public class DataShow3 {
	public static void main(String[] args) throws Exception{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Name the location you want to see the departments: ");
		String location = scanner .nextLine();
		ArrayList<Department> departmentList=new ArrayList<>();
		DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();
		//Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = dbHandler.getConnection();
		String sqlStatement="Select * from department where location=?";
		PreparedStatement statement=connection.prepareStatement(sqlStatement);
		statement.setString(1, location);
		
		ResultSet resultSet=statement.executeQuery();
		while (resultSet.next()) {
			int id=resultSet.getInt(1);
			String name=resultSet.getString(2);
			String location1=resultSet.getString(3);
			Department department=new Department(id,name,location1);
			departmentList.add(department);
		}
		connection.close();
		departmentList.forEach(dept->System.out.println(dept));
	}
}