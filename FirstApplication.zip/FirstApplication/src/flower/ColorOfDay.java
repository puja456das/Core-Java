package flower;
import java.util.Scanner;
public class ColorOfDay {

	public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter color name");
    String colorName=sc.nextLine();
    switch(colorName) {
    case "white" : System.out.println("Color of Monday");break;
    case "red" : System.out.println("Color of Tuesday");break;
    case "green" : System.out.println("Color of Wednesday");break;
    case "yellow" : System.out.println("Color of Thursday");break;
    case "pink" : System.out.println("Color of Friday");break;
    case "black" : System.out.println("Color of saturday");break;
    case "magneta" : System.out.println("Color of sunday");break;
    default: System.out.println("Sorry no day is assigned to this color");break;
    }
System.out.println("Prog is over");
	}

}
