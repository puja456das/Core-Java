package flower;
import java.util.Scanner;
public class PrePost {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=5;
		int j=5;
		//System.out.println(++i);
		//System.out.println(i);
		System.out.println(j++);
		System.out.println(j);
		

	}

}
