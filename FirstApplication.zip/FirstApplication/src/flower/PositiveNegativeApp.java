package flower;
import java.util.Scanner;

public class PositiveNegativeApp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int x=sc.nextInt();
		if(x>0) {
			System.out.println("Positive number");
		}
		else if(x<0) {
			System.out.println("Negative number");
		}
		else {
			System.out.println("It is 0,neither -ive nor _ive");
		}
	}

}
