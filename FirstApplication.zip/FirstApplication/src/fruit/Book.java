package fruit;

public class Book {
	Integer bookNumber;

	String bookTitle;

	String author;

	public Book(Integer bookNumber, String bookTitle, String author) {
		super();
		this.bookNumber = bookNumber;
		this.bookTitle = bookTitle;
		this.author = author;
	}
	

}
