package fruit;
import java.util.*;

public class JavaApp2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the radious");
		double radious=sc.nextDouble();
		double perimeter=3.1416*radious*radious;
		double area=2*3.1416*radious;
		System.out.println("The area of the circle is:"+perimeter);
		System.out.println("The perimeter of the circle is:"+area);
		
		

	}

}
