package fruit;

public class Base {

	
		// TODO Auto-generated method stub
		private int i;
		public Base() {
			i=10;
			System.out.println("Parent constructor");
		}
		public void show() {
			System.out.println("the value of i:"+i);
		}
	

	}


