package fruit;
import java.util.*;

public class JavaApp1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1st operand:");
		int x=sc.nextInt();
		System.out.println("Enter 2nd operand:");
		int y=sc.nextInt();
		int z=x+y;
		System.out.println(z);
				
				
		

	}

}
