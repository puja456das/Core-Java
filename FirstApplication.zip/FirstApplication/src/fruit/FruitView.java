package fruit;
import flower.*;//import statement import classes of a foreign package in current application
public class FruitView {

	public static void main(String[] args) {
		Rose.show();
	}

}
