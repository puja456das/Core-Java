package fruit;

public class Derive extends Base {
	private double j;
	public Derive() {
		j=3.75;
		System.out.println("Child constructor");
	}
   protected void display() {
	   show();
    	System.out.println("the value of j:" +j);
    }
}

