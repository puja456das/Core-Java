package fruit;

public class InheritMain {

	public static void main(String[] args) {
		Derive d=new Derive();
		d.display();
		

	}

}
