
import java.util.Random;
import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();

        System.out.print("Input: ");
        char targetChar = scanner.nextLine().charAt(0);

        
        int frequency = 0;
        for (char c : inputString.toCharArray()) {
            if (c == targetChar) {
                frequency++;
            }
        }

        System.out.println("Frequency of " + targetChar + " = " + frequency);

        
        StringBuilder finalString = new StringBuilder();
        boolean capitalizeNext = false;
        for (char c : inputString.toCharArray()) {
            if (Character.isWhitespace(c)) {
                capitalizeNext = true;
            } else if (capitalizeNext && Character.isLowerCase(c)) {
                finalString.append(Character.toUpperCase(c));
                capitalizeNext = false;
            } else {
                finalString.append(c);
                capitalizeNext = false;
            }
        }

        
        char[] specialChars = "!@#$%^&*".toCharArray();
        char randomSpecialChar = specialChars[random.nextInt(specialChars.length)];

        finalString.append(" ").append(randomSpecialChar);

        System.out.println("Final string = " + finalString.toString());

        scanner.close();
    }
}