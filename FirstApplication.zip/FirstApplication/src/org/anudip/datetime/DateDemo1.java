package org.anudip.datetime;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.Date;

public class DateDemo1 {
	public static void main(String[] args) throws ParseException{
		Scanner scanner=new Scanner(System.in);
		//pattern for date input
		
		SimpleDateFormat dateFormat=new SimpleDateFormat("dd-MM-yyyy");
		System.out.println("Enter batch start Date (dd-MM-yyyy):");
		String startDate=scanner.nextLine();
		//System.out.println(startDate);
		//validate the date
		Date batchDate=dateFormat.parse(startDate);
		System.out.println("batchDate");
	}

}
