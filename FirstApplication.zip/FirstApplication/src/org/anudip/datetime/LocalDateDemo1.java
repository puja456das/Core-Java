package org.anudip.datetime;

import java.time.LocalDate;
public class LocalDateDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate ld=LocalDate.now();
		System.out.println(ld);
		LocalDate ld2=ld.plusDays(3);
		System.out.println(ld2);
		LocalDate ld3=ld.minusDays(3);
		System.out.println(ld3);
		
		LocalDate ld4=LocalDate.of(2023, 06, 29);
		System.out.println(ld4);

	}

}
