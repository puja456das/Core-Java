package org.anudip.string;

import java.util.Scanner;
import java.util.StringTokenizer;

public class StringToken2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a sentence: ");
		String str=sc.nextLine();
		StringTokenizer stk=new StringTokenizer(str,",.' '");
		System.out.println("The number of words:"+stk.countTokens());
		System.out.println("Display all words");
		while(stk.hasMoreTokens()) {
			String stg=stk.nextToken();
			System.out.println(stg);

	}

}
}
