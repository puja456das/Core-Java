package org.anudip.string;
import java.util.Scanner;
public class StringApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a name");
		String name=sc.nextLine();
		String myName=name.toLowerCase();
		if(myName.startsWith("Mr")) {
			System.out.println("Good Afternoon sir");
		}
		else if(myName.startsWith("Mrs") || myName.startsWith("Ms")) {
			System.out.println("Good Afernoon madam");
		}
		else
			System.out.println("Good Afternoon");
		System.out.println(name);
			
  
	}
      
}
