package org.anudip.string;

public class StringDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="ABCDEFGH";
		/*char ch1=str.charAt(0);
		System.out.println(ch1);
		char ch2=str.charAt(7);
		System.out.println(ch2);*/
		System.out.println("The length of str:"+str.length());
		for(int i=0;i<str.length();i++) {
			char ch=str.charAt(i);
			System.out.println(ch);
		}

	}

}
