package org.anudip.string;

public class StringDemo7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       String str="Mary Ann jones";
       String[] arr=str.split(" ");
       System.out.println(arr[0]);
       System.out.println(arr[1]);
       System.out.println(arr[2]);

	}

}
