package org.anudip.string;
import java.util.Scanner;
public class StringPalindrom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a word");
		String myword=scanner.nextLine();
		StringBuffer sb=new StringBuffer(myword);
		sb.reverse();
		String rword=sb.toString();
		if(myword.equalsIgnoreCase(rword))
		{
			System.out.println(myword+" is a palindrome");
		}
		else
			System.out.println(myword+" is not a palindrome");

	}

 }
