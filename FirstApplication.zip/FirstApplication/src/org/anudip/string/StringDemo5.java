package org.anudip.string;
import java.util.Scanner;
public class StringDemo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a name of person");
		String pname=scanner.nextLine();
		if(pname.endsWith("a")||pname.endsWith("i"))
		System.out.println("Name of a girl");
		else 
		System.out.println("Name of a boy");
				
		

	}

}
