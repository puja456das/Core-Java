package org.anudip.string;

public class StringDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="ABCDEFGH";
		char[] arr=str.toCharArray();
		System.out.println("The length of arr:"+arr.length);
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}

	}

}
