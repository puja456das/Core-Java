package org.anudip.string;

public class StringDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
