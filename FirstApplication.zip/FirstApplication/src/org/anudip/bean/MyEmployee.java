package org.anudip.bean;

public class MyEmployee {
	private Integer employeeId;
	private String employeeName;
	private Address empAddress;
	private String DeptName;
	private Double Salary;
	

	public MyEmployee(Integer employeeId, String employeeName, Address empAddress, String deptName, Double salary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.empAddress = empAddress;
		DeptName = deptName;
		Salary = salary;
	}


	public MyEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Integer getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public Address getEmpAddress() {
		return empAddress;
	}


	public void setEmpAddress(Address empAddress) {
		this.empAddress = empAddress;
	}


	public String getDeptName() {
		return DeptName;
	}


	public void setDeptName(String deptName) {
		DeptName = deptName;
	}


	public Double getSalary() {
		return Salary;
	}


	public void setSalary(Double salary) {
		Salary = salary;
	}


	@Override
	public String toString() {
		String output=String.format("%-5s %-15s %-25s %-10s %-10s",employeeId,employeeName,empAddress,DeptName,Salary);
		return  output;
		
	}
	
	
	
	
}
