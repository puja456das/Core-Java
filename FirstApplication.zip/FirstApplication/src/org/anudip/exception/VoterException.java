package org.anudip.exception;

 public class VoterException extends Exception {
	 static final long serialVersionUID=2L;
	 public VoterException(String message) 
		{	
			super(message);

}
 }
