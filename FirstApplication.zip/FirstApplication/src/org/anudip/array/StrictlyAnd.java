package org.anudip.array;

public class StrictlyAnd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10;
		int j=20;
		if(++i>5 && ++j>15)
			System.out.println("hello");
		else
			System.out.println("hi");
		System.out.println("The value of i:"+i);
		System.out.println("The value of j:"+j);

	}

}
