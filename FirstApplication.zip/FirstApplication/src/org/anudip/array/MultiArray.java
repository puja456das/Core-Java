package org.anudip.array;

public class MultiArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int [][] arr= {{20,30,40,50},{65,25,35,75},{80,90,10,60}};
   for(int row=0;row<3;row++) {
	   System.out.println();
	   for(int col=0;col<4;col++) {
		   System.out.print(arr[row][col]+" ");
	   }
   }
	}

}
