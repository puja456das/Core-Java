package org.anudip.array;

public class LoopDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int counter=0;
		while(counter<5);
		System.out.println("Hello");
		counter++;
	}
	
}
	
	

