package org.anudip.array;

import java.util.Arrays;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {25,41,63,28,91,10,47,89,25,78};
		System.out.println("The size of the array="+arr.length);
		System.out.println("Display");
		for(int i=0;i<arr.length;i++)
		{
	 System.out.println(arr[i]);
		}
		Arrays.sort(arr);//sorting an array
		System.out.println("Display after sort in ascending order:");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		System.out.println("Display after sort in descending order: ");
		for(int i=arr.length-1;i>=0;i--) {
			System.out.println(arr[i]);
		}
	}

}
