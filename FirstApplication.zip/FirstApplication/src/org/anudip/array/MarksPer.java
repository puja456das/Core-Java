package org.anudip.array;
import java.util.Scanner;
public class MarksPer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner scanner=new Scanner(System.in);
     System.out.println("Enter marks percentage of a student");
     int x=Integer.parseInt(scanner.nextLine());
     if(x>89) {
    	 System.out.println("E");
    	 
    		 
    	 }
     else if(x>74){
    		 System.out.println("V");
    	 }
     else if(x>59) {
    		 System.out.println("G");
    	 }
     else if(x>=50) {
    	 System.out.println("P");
     }
    	 else {
    		 System.out.println("F");
    	 }
    		 
    	 }
	}


