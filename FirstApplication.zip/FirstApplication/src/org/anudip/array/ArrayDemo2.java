package org.anudip.array;

public class ArrayDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {25,41,63,28,91,10,47,89,25,78};
		System.out.println("The size of the array="+arr.length);
		System.out.println("Display");
		for(int x:arr) {
			System.out.println(x);
		}

	}

}
