package org.anudip.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pattern p1=Pattern.compile("[a-z]{3,}s");
		String s1="hows";
		String s2="bus";
		String s3="ds";
		String s4="thees";
		Matcher m1=p1.matcher(s1);
		System.out.println(m1.matches());
		
		Matcher m2=p1.matcher(s2);
		System.out.println(m2.matches());
		
		Matcher m3=p1.matcher(s3);
		System.out.println(m3.matches());
		
		Matcher m4=p1.matcher(s4);
		System.out.println(m4.matches());
		


	}

}
