package org.anudip.regex;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegexApp2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your mail address:");
		String s1=sc.nextLine();
		Pattern p1=Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@gmail.com");
		Matcher m1=p1.matcher(s1);
		if(m1.matches()) {
			System.out.println("It is valid");
		}
		else
		{
			System.out.println("not valid");
		}

	 }

}
