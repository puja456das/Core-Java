package org.anudip.regex;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegexDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pattern p1=Pattern.compile(".s");
		String s1="is";
		Matcher m1=p1.matcher(s1);
		System.out.println(m1.matches());
		Pattern p2=Pattern.compile("..s");
		String s2="bus";
		Matcher m2=p2.matcher(s2);
		System.out.println(m2.matches());
		Pattern p3=Pattern.compile("s.");
		String s3="so";
		Matcher m3=p3.matcher(s3);
		System.out.println(m3.matches());

	}

}
