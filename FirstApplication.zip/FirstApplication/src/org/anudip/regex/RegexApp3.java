package org.anudip.regex;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegexApp3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your joining Date");
		String Date=sc.nextLine();
		Pattern p1=Pattern.compile("^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4}$");
		Matcher m1=p1.matcher(Date);
		
		if(m1.matches()) {
		System.out.println("Valid joining date");

       }
		else {
			System.out.println("Not valid joining date");

   }
	}
}
