package org.anudip.interfaceApp;

public interface MyDemoFace {
	public void show();
	public default void display() {
		System.out.println("Hello How are you?");
	}
	public static void putdata() {
		System.out.println("hi hello people");
	}
}
