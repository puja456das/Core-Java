package org.anudip.interfaceApp;

public interface Shape {
	public String perimeter();
	public String area();
	double pi=3.1416;

}
