package org.anudip.interfaceApp;

public class CircleApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
