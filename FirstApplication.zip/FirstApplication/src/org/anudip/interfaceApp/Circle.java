package org.anudip.interfaceApp;

public class Circle implements Shape {
	int r=2;

	@Override
	public String perimeter() {
		double radious=0;
		double perimeter=2*3.1416*radious;
		System.out.println("Perimeter of circle:"+perimeter);
		return null;
		
		
		
		
	}

	@Override
	public String area() {
		double radious=0;
		double area=3.1416*radious*radious;
		System.out.println("Perimeter of area"+area);
		return null;
		
	}

}

