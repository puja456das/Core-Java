package org.anudip.io;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FileOutput2 {
	public static void main(String[] args) throws IOException {
			Scanner scanner=new Scanner(System.in);
			//FileWriter object points to File Lotus.txt in Write mode
			FileOutputStream fileOut=new FileOutputStream("d:/tulip.txt",true);
			BufferedOutputStream bufferedOut=new BufferedOutputStream(fileOut);
			//accept data from user
			System.out.println("Enter a Text");
			
			String str="\n"+scanner.nextLine();
			
			// converting from String to byte
			byte [] byteArr=str.getBytes();
			bufferedOut.write(byteArr);
			bufferedOut.flush();
			bufferedOut.close();
			scanner.close();
			System.out.println("File written");

			
			
		}

	}
