package org.anudip.io;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class FileIn2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream fileIn=new FileInputStream("d:/lotus.txt");
		
		//BufferedReader will read inside the file which fileReader is pointing to i.e lotus.txt
		BufferedInputStream bufferedIn=new BufferedInputStream(fileIn);
		while(true) {
			int x=bufferedIn.read();
			if(x==-1)//-1 means end of file
				break;
			char ch=(char)x;
			System.out.print(ch);
		
		}
		fileIn.close();
		bufferedIn.close();

	}
}


