package org.anudip.application;

import java.util.Scanner;
import java.text.DecimalFormat;

public class CircleApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter radius of a circle:");
		double radius=Double.parseDouble(scanner.nextLine());
		Circle circle=new Circle(radius);
		double perimeter=circle.perimeterCalculation();
		double area=circle.areaCalculation();
		DecimalFormat myFormat=new DecimalFormat("0.0#");
		String perimeterStr=myFormat.format(perimeter);
		System.out.println("Perimeter:"+perimeterStr);
		String areaStr=myFormat.format(area);
		System.out.println("Area:"+areaStr);
        scanner.close();
	}

 }
