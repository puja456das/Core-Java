package org.anudip.Thread;

public class ThreadCommunication {

	
		public static void main(String[] args) {
			Thread1 t1=new Thread1();
			t1.start();
			

		}//end of void main

	}//end of threadcommunication class

	


