package org.anudip.Thread;


	public class Thread2 extends Thread{
		private String word;
		private String rword;
		public Thread2(String word) {
			this.word=word;
			this.rword=null;
		}
		public String show() {
			return rword;
		}
		public void run() {
			try {
				synchronized(this)
				{
			
			StringBuilder sb=new StringBuilder(word);
			sb.reverse();
			rword=sb.toString();
			notifyAll();
		}
	}catch(Exception e) {}

	}
	}

