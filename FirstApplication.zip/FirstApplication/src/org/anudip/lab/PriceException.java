package org.anudip.lab;

public class PriceException extends RuntimeException {
	 static final long serialVersionUID=1L;
	 public PriceException(String message) { 
		
			super(message); 

}
}
		
