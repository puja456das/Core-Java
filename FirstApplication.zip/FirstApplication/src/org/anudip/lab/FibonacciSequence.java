package org.anudip.lab;

import java.util.Scanner;

public class FibonacciSequence {

	public static void main(String[] args) {
		//declare a scanner object
		Scanner scanner=new Scanner(System.in);
		//ask to enter a number
		System.out.println("Enter a Positive number");
		int n=scanner.nextInt();
		int n1=0;
		int n2=1;
		int result=0;
		while(result < n) {
			result=n1+n2;
			n1=n2;
			n2=result;
		}//end of while loop
		
		if(result==n) {
			System.out.println("yes");
		}
		else 
		System.out.println("no");
		

	}//end of main

}//end of class
