package org.anudip.lab;

public class BillService {
	public static String billCalculation(Consumer consumer) {
        int unitConsumed = consumer.getUnitConsumed();
        double amountPayable;

        if (unitConsumed <= 200) {
            amountPayable = 300.0;
        } else if (unitConsumed <= 500) {
            amountPayable = 300.0 + (unitConsumed - 200) * 1.25;
        } else if (unitConsumed <= 1000) {
            amountPayable = 300.0 + 300.0 + (unitConsumed - 500) * 1.0;
        } else {
            amountPayable = 300.0 + 300.0 + 500.0 + (unitConsumed - 1000) * 0.75;
        }

        // Round the amountPayable to 2 decimal places
        String finalPayment = String.format("%.2f", amountPayable);
        consumer.setFinalPayment(finalPayment);

        return finalPayment;
    }
}


