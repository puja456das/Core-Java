package org.anudip.lab;

import java.util.Arrays;
import java.util.Scanner;

public class Anagram {
	public static boolean checkAnagram(String string1,String string2) {
		// Remove all the white space
		string1 = string1.replaceAll("\\s", "");
        string2 = string2.replaceAll("\\s", "");
        
     // Check if both length matches
		if (string1.length() != string2.length()) {
		    return false;
		    }
		
		// Convert both Strings into lower case and into Character Array
		    char[] array1 = string1.toLowerCase().toCharArray();
		    char[] array2 = string2.toLowerCase().toCharArray();
		    
		 // Sort both Character Array
		    Arrays.sort(array1);
		    Arrays.sort(array2);
		    
		    // Check if both arrays are equal
		    return Arrays.equals(array1, array2);
		}

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		
		// Accept the two strings
		System.out.println("Enter the first string");
		String string1=scanner.nextLine();
		System.out.println("Enter the second string");
		String string2=scanner.nextLine();
		//Display the result
		if(checkAnagram(string1,string2))
			System.out.println(string1+" and "+string2+" are Anagrams");
        else
            System.out.println(string1+" and "+string2+" are NOT Anagrams");
		scanner.close();
			

	}

}
