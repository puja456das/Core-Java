package org.anudip.lab;

import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Pattern;

public class PanCardIDValidatorAndArranger {
	
		public static boolean isValidPanCard(String panCardID) {
	        return Pattern.matches("^[a-zA-Z0-9]{10}$", panCardID);
	    }
	    public static String arrangePanCardID(String panCardID) {
	        // Convert any lowercase alphabets to uppercase
	        panCardID = panCardID.toUpperCase();
	        // Extract alphabets and numbers separately
	        String alphabets = panCardID.replaceAll("[^A-Z]", "");
	        String numbers = panCardID.replaceAll("[^0-9]", "");
	        // Check if both alphabets and numbers exist and have a length of atleast 1 characters
	        if (alphabets.length() == 0 | numbers.length() == 0) {
	            return "Invalid";
	        }
	        // Convert the numbers part to an array and sort it in ascending order
	        char[] numberArray = numbers.toCharArray();
	        Arrays.sort(numberArray);
	        numbers = new String(numberArray);
	        // Convert the alphabets part to an array and sort it in descending order
	        char[] alphabetArray = alphabets.toCharArray();
	        Arrays.sort(alphabetArray);
	        StringBuilder reversedAlphabets = new StringBuilder(new String(alphabetArray));
	        reversedAlphabets.reverse();
	        alphabets = reversedAlphabets.toString();
	        // Combine the sorted numbers and alphabets
	        return numbers + alphabets;
	    }
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter PAN card ID: ");
	        String panCardID = scanner.nextLine();
	        if (isValidPanCard(panCardID)) {
	            String arrangedPanCardID = arrangePanCardID(panCardID);
	            System.out.println("Arranged PAN card ID: " + arrangedPanCardID);
	        } else {
	            System.out.println("Invalid");
	        }
	        scanner.close();
	    }
    }


