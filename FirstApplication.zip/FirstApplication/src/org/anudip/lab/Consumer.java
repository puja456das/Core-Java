package org.anudip.lab;

//Declaring the Consumer Class

class Consumer {
  private String id;    //Declaring Private String ID Method
  private String name;  //Declaring Private String Name Method
  private int unitConsumed;  //Declaring Private Integer Unit Consumed Method
  private String finalPayment; //Declaring Private String Final Payment Method

  // Constructors
  public Consumer(String id, String name, int unitConsumed) {
      this.id = id;
      this.name = name;
      this.unitConsumed = unitConsumed;
  }//end of Constructors

  // Getters and setters
  public String getId() { //Getter for Id
      return id;
  }

  public void setId(String id) { //Setter for Id
      this.id = id;
  }

  public String getName() { //Getter for Name
      return name;
  }

  public void setName(String name) { //Setter for Name
      this.name = name;
  }

  public int getUnitConsumed() { //Getter for Unit Consumed
      return unitConsumed;
  }

  public void setUnitConsumed(int unitConsumed) { //Setter for Unit Consumed
      this.unitConsumed = unitConsumed;
  }

  public String getFinalPayment() { //Getter for Final Payment
      return finalPayment;
  }

  public void setFinalPayment(String finalPayment) { //Setter for Final Payment
      this.finalPayment = finalPayment;
  }

  // Override toString()
  @Override
  public String toString() { //Using the String toString format
      return String.format("%-5s %-20s %-10s %-10s", id, name, unitConsumed, finalPayment);
  }//end of String toString Method
  
}//end of Consumer Class