package org.anudip.lab;

public class ResultService {

	public static String gradeCalculation(StudentResult result) 
	{
		double total=result.getHalfYearlyTotal() + result.getAnnualTotal();
        double percentage = (total / 1000) * 100;
        if (percentage >= 90) {
            return "E";
        } else if (percentage >= 75) {
            return "V";
        } else if (percentage >= 60) {
            return "G";
        } else if (percentage >= 45) {
            return "P";
        } else {
            return "F";
        }
		
	

   }

}
