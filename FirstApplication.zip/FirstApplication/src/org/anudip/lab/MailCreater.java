package org.anudip.lab;

import java.util.Scanner;

public class MailCreater {
	public static String createMailAccount(String studentName) {
		//convert student name to lower case
		studentName=studentName.toLowerCase();
		String []arr=studentName.split(" ");
		String result=studentName.replace(' ','.');
	    String mailID=result+"@tsr.edu";
		return mailID;
		
	}
   
	 public static void main(String[] args) {
		//declare Scanner object
		Scanner scanner=new Scanner(System.in);
		//ask to enter a name & accept
		System.out.println("Enter a student Name");
		String studentName=scanner.nextLine();
		//invokes the createMailAccount method
		String mailId=createMailAccount(studentName);
		//display output
        System.out.println("Student's mail id:" +mailId);
	}

}
