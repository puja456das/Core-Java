package org.anudip.lab;

import java.util.Scanner;
   public class ApplicantMain {
	
	public static int totalCalculation(Applicant applicant) 
	{
		if ((applicant.getSubject1()<50 || applicant.getSubject2()<50 || applicant.getSubject3()<50)) 
         return 0;
         else {
        int total = applicant.getSubject1() + applicant.getSubject2() + applicant.getSubject3();
        return total;
         }
	}

	 private static int percentageCalculation (int total) {
	        double val = ((double )total/300)*100;
	        int percentage = (int)val;
	        return percentage;
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
		 System.out.println("Enter Number of Applicants:: ");
	        int no=Integer.parseInt(scanner.nextLine());
	        Applicant[] applicantArr = new Applicant[no];
	        for(int i = 0;i<no;i++)
	        {
        System.out.println("Enter Applicant's Details:: ");
        String details= scanner.nextLine();
        String detailArr[] = details.split(","); 
        int sub1= Integer.parseInt(detailArr[1]);
        int sub2= Integer.parseInt(detailArr[2]);
        int sub3= Integer.parseInt(detailArr[3]);
        Applicant applicant = new Applicant(detailArr[0],sub1,sub2,sub3);
        int total=totalCalculation(applicant);
        int percentage=percentageCalculation(total);
        applicant.setTotal(total);
        applicant.setPercentage(percentage);
        applicantArr[i]=applicant;
        }
            for (Applicant applicant:applicantArr) {
            	if(applicant==null)
            	continue;
            	if(applicant.getTotal()!=0) {
            		System.out.println("Error message");
            	if(applicant.getPercentage()>=70)
            		System.out.println(applicant);
            	}
            }
            
        }  
	}