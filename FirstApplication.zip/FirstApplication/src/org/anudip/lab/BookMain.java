package org.anudip.lab;

import java.util.List;
import java.util.Scanner;

//Declaring the class Bookmain
public class BookMain {
	
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); //Create a Scanner object to read user input
        BookService bookService = new BookService();//Create an instance of BookService
        List<Book> bookList = Library.getAllBooks();//Get the list of books from the Library

        while (true) {
            System.out.println("Menu\n");
            System.out.println("1. Display Book Number-wise");
            System.out.println("2. Display Book Title-wise");
            System.out.println("3. Display Book Author-wise");
            System.out.println("4. Exit\n");
            System.out.print("Enter choice (1-4): ");

            int choice = scanner.nextInt();//Read the user's choice

            switch (choice) {
                case 1:
                    bookList = bookService.arrangeBooksNumberWise(bookList);
                    break;
                case 2:
                    bookList = bookService.arrangeBooksTitleWise(bookList);
                    break;
                case 3:
                    bookList = bookService.arrangeBooksAuthorWise(bookList);
                    break;
                case 4:
                    System.out.println("Exit");
                    scanner.close();//close the scanner
                    return;//Exit the program
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
     //Displays the books based on sorting choice in the mentioned formatted manner with headings
            System.out.println("\nBook Number         Book Title                    Author");
            for (Book book : bookList) {
                System.out.println(book);
            }
            System.out.println();
        }
    }
}

