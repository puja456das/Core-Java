package org.anudip.app;
import java.util.Scanner;
public class Perimeter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the shape");
		String menu=sc.nextLine();
		switch(menu) {
		case("square"):
			System.out.println("Enter the side:");
		int s=Integer.parseInt(sc.nextLine());
		int perimeter1=4*s;
		System.out.println("Perimeter of square:"+perimeter1);
		break;
		case("rectangle"):
			System.out.println("Enter the length");
		int l=Integer.parseInt(sc.nextLine());
		System.out.println("Enter the base");
		int b=Integer.parseInt(sc.nextLine());
		int perimeter2=2*(l+b);
		System.out.println("Perimeter of rectangle:"+perimeter2);
		break;
		case("circle"):
			System.out.println("Enter the radious");
		int r=Integer.parseInt(sc.nextLine());
		int perimeter3=2 * (22/7) * r;
		System.out.println("Perimeter of circle:"+perimeter3);
		break;
		default:System.out.println("User Entered invalid shape");
			
		
		}
		System.out.println("Program is close");

	}

 }
