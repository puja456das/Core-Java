package org.anudip.inheritance;

public class Parent1 {
	private int i;
	public Parent1() {
		i=10;
		System.out.println("Parent constructor");
	}
	public void show() {
		System.out.println("the value of i:"+i);
	}
}

	
		

	


