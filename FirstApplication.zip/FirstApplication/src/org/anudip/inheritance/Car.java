package org.anudip.inheritance;

 class Car extends Vehicle {
private String color;
public Car() {
	color="Red";
}
public void honk() {
	System.out.println("The color of the car is:"+color);
}
}
