package org.anudip.inheritance;

public class Vehicle {
	private  String brand;
	private String model;
	private int year;
	public Vehicle() {
		brand="Ford";
		model="Mustang";
		year=2020;
		
		
	}
	public void drive() {
		System.out.println("The car brand:"+brand+",model is:"+model+"and year of car:"+year);
	}

}
