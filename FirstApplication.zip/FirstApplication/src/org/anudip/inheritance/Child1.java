package org.anudip.inheritance;

public class Child1 extends Parent1 {
	private double j;
	public Child1() {
		j=3.75;
		System.out.println("Child constructor");
	}
    public void display() {
    	System.out.println("the value of j:" +j);
    }
}
