package org.anudip.inheritance;

public class Person {
	private String name;
	private int age;
	public Person() {
		name="Puja";
		age=21;
		
	}
   public void speak() {
	   System.out.println("Person name and age:"+name+","+age);
   }
}
