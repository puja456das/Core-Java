package org.anudip.inheritance;

public class InheritMain3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car c=new Car();
		c.drive();
		c.honk();

	}

}
