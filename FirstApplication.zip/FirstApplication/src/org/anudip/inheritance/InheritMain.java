package org.anudip.inheritance;

public class InheritMain {

	public static void main(String[] args) {
	  //Child ch=new Child();
	  //ch.display();
	  //ch.show();
	  Parent1 p=new Child1();
	  p.show();
	  System.out.println("The hash code of p:"+p.hashCode());
      Child1 cc=(Child1)p;
      System.out.println("The hash code of cc:"+cc.hashCode());
      cc.display();
	}

}
