package org.anudip.inheritance;

public class InheritMain2 {

	public static void main(String[] args) {
		Parent2 p=new Child2();
		p.show();

	}

}

