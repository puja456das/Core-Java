
import java.util.HashMap;

import java.util.Map;

import java.util.Scanner;

public class Main2 {

public static void main(String[] args) {

Scanner sc = new Scanner(System.in);

String inputStr = sc.nextLine();

String toReplace = sc.nextLine();

String replaceWith =sc.nextLine();


String outputStr = replaceAndAddNumbers(inputStr, toReplace, replaceWith);

System.out.println(outputStr);

}

public static String replaceAndAddNumbers(String inputStr, String toReplace, String replaceWith) {

Map<Character, Integer> charToNumber = new HashMap<>();

charToNumber.put('a', 1);

charToNumber.put('b', 2);

charToNumber.put('c', 3);

charToNumber.put('d', 4);

charToNumber.put('e', 5);

charToNumber.put('f', 6);

charToNumber.put('g', 7);

charToNumber.put('h', 8);

charToNumber.put('i', 9);

charToNumber.put('j', 10);

charToNumber.put('k', 11);

charToNumber.put('l', 12);

charToNumber.put('m', 13);

charToNumber.put('n', 14);

charToNumber.put('o', 15);

charToNumber.put('p', 16);

charToNumber.put('q', 17);

charToNumber.put('r', 18);

charToNumber.put('s', 19);

charToNumber.put('t', 20);

charToNumber.put('u', 21);

charToNumber.put('v', 22);

charToNumber.put('w', 23);

charToNumber.put('x', 24);

charToNumber.put('y', 25);

charToNumber.put('z', 26);



String replacedStr = inputStr.replace(toReplace, replaceWith);



StringBuilder numberStr = new StringBuilder();

for (char ch : replaceWith.toLowerCase().toCharArray()) {

if (charToNumber.containsKey(ch)) {

numberStr.append(charToNumber.get(ch));

}

}



String outputStr = replacedStr + " " + numberStr.toString();

return outputStr;

}

}