public class Main {
    public static void main(String[] args) {
        int N1 = 10;
        int result1 = findNthTerm(N1);
        System.out.println("Nth term for N = " + N1 + " is: " + result1);

        int N2 = 7;
        int result2 = findNthTerm(N2);
        System.out.println("Nth term for N = " + N2 + " is: " + result2);
    }

    public static int findNthTerm(int N) {
        if (N % 2 == 0) {
            return (N / 2) * 220;
        } else {
            return (N / 7) *  1100+550;
        }
    }
}



